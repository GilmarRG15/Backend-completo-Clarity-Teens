﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clarity_teens_app
{
    public class Contacto
    {
        public int Id { get; set; }

        public string? NombreCompleto { get; set; }

        public string? CorreoElectronico { get; set; }

        public string? Mensaje { get; set; }

        public DateTime FechaRegistro { get; set; }

        public string? Transaccion { get; set; }
    }
}
