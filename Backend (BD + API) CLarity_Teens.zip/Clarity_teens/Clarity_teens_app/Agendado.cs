﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clarity_teens_app
{
    public class Agendado
    {
        public int Id { get; set; }
        public string? NombreDoctor { get; set; }
        public string? NombreEspecialidad { get; set; }
        public DateTime FechaAgendado { get; set; }
        public string? Estado { get; set; }
    }
}
