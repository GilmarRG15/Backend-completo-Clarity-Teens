﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clarity_teens_app
{
    public class Doctor
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public Especialidad? Especialidad {  get; set; } 
        public String? Disponibilidad { get; set; }
        public double Tarifa { get; set; }
        public float Calificacion { get; set; }
        public string? Transaccion { get; set; }
    }
}
