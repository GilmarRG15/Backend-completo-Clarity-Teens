﻿namespace Clarity_teens_app
{
    public class Usuario
    {
        public int Id { get; set; }
        public string? Cedula { get; set; }
        public string? Nombre { get; set; }
        public string? Apellido { get; set; }
        public string? Email {  get; set; }
        public string? Clave { get; set; }
        public string? Transaccion { get; set; }
    }
}
