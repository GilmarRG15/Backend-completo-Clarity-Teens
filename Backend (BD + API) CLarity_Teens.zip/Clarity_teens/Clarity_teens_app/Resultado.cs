﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clarity_teens_app
{
    public class Resultado
    {
        public string? Respuesta { get; set; }
        public string? Leyenda { get; set; }
    }
}
