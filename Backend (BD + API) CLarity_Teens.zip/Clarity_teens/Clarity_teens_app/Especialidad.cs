﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clarity_teens_app
{
    public class Especialidad
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
    }
}
