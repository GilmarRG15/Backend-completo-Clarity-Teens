﻿using API.Shared;
using Clarity_teens_app;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Xml.Linq;

namespace Clarity_teens.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    //[Authorize]
    public class DoctorController : Controller
    {

        [Route("[action]")]
        [HttpPost]
        public async Task<ActionResult<List<Doctor>>> GetDoctores(
            [FromBody] Doctor doctorTmp)
        {
            var cadenaConexion = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build()
                .GetSection("ConnectionStrings")["Conexion"];

            XDocument xmlParam = DBXmlMethods.GetXml(doctorTmp);
            DataSet dsResultado = await DBXmlMethods.EjecutaBase(
               "GetDoctores", cadenaConexion,
                doctorTmp.Transaccion, xmlParam.ToString());

            List<Doctor> listDoctor = new List<Doctor>();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    foreach (DataRow row in dsResultado.Tables[0].Rows)
                    {
                        listDoctor.Add(new Doctor
                        {
                            Id = Convert.ToInt32(row["id"]),
                            Nombre = row["nombre"].ToString(),
                            Especialidad = new Especialidad
                            {
                                Id = Convert.ToInt32(row["idEspecialidad"]),
                                Nombre = row["nombreEspecialidad"].ToString()
                            },
                            Disponibilidad = row["disponibilidad"].ToString(),
                            Tarifa = Convert.ToDouble(row["tarifa"]),
                            Calificacion = Convert.ToSingle(row["calificacion"])

                        });
                    }
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }

            return Ok(listDoctor);
        }


        [Route("[action]")]
        [HttpPost]
        public async Task<ActionResult<List<Agendado>>> GetAgendados(
     [FromBody] Doctor doctorTmp)
        {
            var cadenaConexion = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build()
                .GetSection("ConnectionStrings")["Conexion"];

            XDocument xmlParam = DBXmlMethods.GetXml(doctorTmp);
            DataSet dsResultado = await DBXmlMethods.EjecutaBase(
                "GetAgendados", cadenaConexion,
                doctorTmp.Transaccion, xmlParam.ToString());

            List<Agendado> listAgendados = new List<Agendado>();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    foreach (DataRow row in dsResultado.Tables[0].Rows)
                    {
                        listAgendados.Add(new Agendado
                        {
                            Id = Convert.ToInt32(row["id"]),
                            NombreDoctor = row["nombreDoctor"].ToString(),
                            NombreEspecialidad = row["nombreEspecialidad"].ToString(),
                            FechaAgendado = Convert.ToDateTime(row["fechaAgendado"]),
                            Estado = row["estado"].ToString()
                        });
                    }
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }

            return Ok(listAgendados);
        }



        [Route("[action]")]
        [HttpPost]
        public async Task<ActionResult<List<Resultado>>> SetDoctores(
           [FromBody] Doctor doctorTmp)
        {
            var cadenaConexion = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build()
                .GetSection("ConnectionStrings")["Conexion"];

            XDocument xmlParam = DBXmlMethods.GetXml(doctorTmp);

            DataSet dsResultado = await DBXmlMethods.EjecutaBase("SetDoctores", cadenaConexion, doctorTmp.Transaccion, xmlParam.ToString());

            Resultado resultado = new Resultado();
            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    foreach (DataRow row in dsResultado.Tables[0].Rows)
                    {
                        Resultado objResponse = new Resultado
                        {
                            Respuesta = row["Respuesta"].ToString(),
                            Leyenda = row["Leyenda"].ToString()
                        };
                        resultado = objResponse;
                    }
                }
                catch (Exception ex)
                {

                }
            }
            return Ok(resultado);
        }
    }
}
