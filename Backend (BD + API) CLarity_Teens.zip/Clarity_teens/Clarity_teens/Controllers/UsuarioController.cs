﻿using API.Shared;
using Clarity_teens_app;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Xml.Linq;

namespace Clarity_teens.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuarioController : Controller
    {

        private readonly IConfiguration _config;
        public UsuarioController(IConfiguration config)
        {
            _config = config;
        }

            [Route("[action]")]
        [HttpPost]
        public async Task<ActionResult<List<Usuario>>> GetUsuario([FromBody] Usuario usuarioTmp)
        {
            var cadenaConexion = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build()
                .GetSection("ConnectionStrings")["Conexion"];

            XDocument xmlParam = DBXmlMethods.GetXml(usuarioTmp);
            DataSet dsResultado = await DBXmlMethods.EjecutaBase("GetUsuario", cadenaConexion,usuarioTmp.Transaccion, xmlParam.ToString());

            List<Usuario> listUsuario = new List<Usuario>();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    if (dsResultado.Tables[0].Rows.Count > 0)
                    {
                        Usuario usuario1 = new Usuario();
                        usuario1.Id = Convert.ToInt32(dsResultado.Tables[0].Rows[0]["id"]);
                        usuario1.Cedula = dsResultado.Tables[0].Rows[0]["cedula"].ToString();

                        return Ok(JsonConvert.SerializeObject (CrearToken(usuario1)));
                    }
                }
                catch (Exception ex)
                {
                    return Ok(JsonConvert.SerializeObject("Error Credenciales"));
                }
            }

            return Ok(listUsuario);
        }

        private string CrearToken(Usuario usuario)
        {
            var clains = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, usuario.Id.ToString()),
                new Claim(ClaimTypes.Name, usuario.Cedula)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config.GetSection("AppSettings:Token").Value));
            var creds = new SigningCredentials(key,SecurityAlgorithms.HmacSha512Signature);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                SigningCredentials = creds,
                Expires = DateTime.Now.AddDays(1),
                Subject = new ClaimsIdentity(clains)
            };
            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
