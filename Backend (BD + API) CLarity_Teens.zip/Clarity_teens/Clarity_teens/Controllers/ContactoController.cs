﻿using API.Shared;
using Clarity_teens_app;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Xml.Linq;

namespace Clarity_teens.Controllers

{
    [ApiController]
    [Route("api/[controller]")]
    public class ContactoController : Controller
    {

        [Route("[action]")]
        [HttpPost]
        public async Task<ActionResult<Resultado>> SetContacto(
    [FromBody] Contacto contactoTmp)
        {
            var cadenaConexion = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build()
                .GetSection("ConnectionStrings")["Conexion"];

            XDocument xmlParam = DBXmlMethods.GetXml(contactoTmp);

            DataSet dsResultado = await DBXmlMethods.EjecutaBase(
                "SetContacto",
                cadenaConexion,
                contactoTmp.Transaccion,
                xmlParam.ToString());

            Resultado resultado = new Resultado();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    foreach (DataRow row in dsResultado.Tables[0].Rows)
                    {
                        resultado = new Resultado
                        {
                            Respuesta = row["respuesta"].ToString(),
                            Leyenda = row["leyenda"].ToString()
                        };
                    }
                }
                catch (Exception)
                {

                }
            }

            return Ok(resultado);
        }
    }
}
